
// This service simulates an AI narrator without needing an API key or external request.

const MESSAGES = {
  critical: [
    "CRITICAL ALERT: VITAL SIGNS FAILING.",
    "SYSTEM WARNING: IMMINENT BIOLOGICAL SHUTDOWN.",
    "YOU ARE DYING. FIND SHELTER.",
    "VISION BLURRING. HEART RATE CRITICAL."
  ],
  lowHealth: [
    "You are bleeding. The scent will attract predators.",
    "The pain is sharp. You need bandages.",
    "Moving is difficult. You are injured.",
    "You leave a trail of blood behind you."
  ],
  lowHunger: [
    "Stomach growling like a beast in the silence.",
    "Caloric reserves depleted. Hunting required.",
    "Starvation clouds your judgment.",
    "You feel weaker with every step."
  ],
  lowThirst: [
    "Throat dry as the wasteland sand.",
    "Dehydration detected. Water source required.",
    "Your skin feels paper-thin and dry.",
    "The heat is becoming unbearable."
  ],
  night: [
    "The darkness hides things you don't want to see.",
    "Something howled in the distance. It sounded close.",
    "Keep your light off if you want to stay hidden.",
    "The temperature is dropping rapidly.",
    "Shadows move when you're not looking."
  ],
  morning: [
    "The sun rises over the ruins. Another day to survive.",
    "The light reveals the horrors of the night.",
    "Birdsong. A rare sign of life.",
    "The fog lifts, revealing the wasteland."
  ],
  general: [
    "The wind carries the scent of sulfur.",
    "Distant gunfire echoes off the mountains.",
    "A chill runs down your spine.",
    "The Geiger counter clicks ominously.",
    "You feel watched from the shadows.",
    "The sun beats down unforgivingly.",
    "A rusted supply drop plane flies overhead.",
    "Silence falls over the wasteland.",
    "You hear the crunch of dry leaves nearby.",
    "The air tastes of metal and ash.",
    "Supplies are scarce. Conserve your energy.",
    "The local wildlife seems agitated.",
    "Is that a footprint? You are not alone."
  ]
};

const pickRandom = (arr: string[]) => arr[Math.floor(Math.random() * arr.length)];

export const getSurvivalTips = async (gameState: any) => {
  // Simulate a small network delay for the "AI" feel
  await new Promise(resolve => setTimeout(resolve, 600));

  const p = gameState.player;

  // Prioritize critical status messages
  if (p.health < 20) return pickRandom(MESSAGES.critical);
  if (p.health < 40) return pickRandom(MESSAGES.lowHealth);
  if (p.hunger < 25) return pickRandom(MESSAGES.lowHunger);
  if (p.thirst < 25) return pickRandom(MESSAGES.lowThirst);

  // Time based messages
  const time = gameState.dayTime; // 0-1440
  const isNight = time > 1100 || time < 300;
  const isMorning = time >= 300 && time < 500;

  if (isNight && Math.random() > 0.4) return pickRandom(MESSAGES.night);
  if (isMorning && Math.random() > 0.6) return pickRandom(MESSAGES.morning);

  // Default atmospheric messages
  return pickRandom(MESSAGES.general);
};
